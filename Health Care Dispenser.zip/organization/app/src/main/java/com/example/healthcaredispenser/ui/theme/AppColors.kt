package com.example.healthcaredispenser.ui.theme

import androidx.compose.ui.graphics.Color

// 앱 공통 팔레트
val LoginGreen = Color(0xFF2E7D32)  // 메인 초록
val HintGray   = Color(0xFF6F7783)  // 힌트/부가 텍스트
val BorderGray = Color(0xFFD0D5DD) // 테두리
val SignBg     = Color(0xFFE8F5E9)  // 회원가입/서브 배경
