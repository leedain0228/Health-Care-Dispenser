package com.example.healthcaredispenser.qr

import com.journeyapps.barcodescanner.CaptureActivity

// ZXing 캡처 화면을 커스터마이즈/세로 고정하기 위한 빈 서브클래스
class CustomCaptureActivity : CaptureActivity()